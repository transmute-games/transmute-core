package GameEngine;

import Meteor.GameEngine.Manager;

public class GameManager extends Manager {
	public GameManager(Game game) {
		super(game);
	}
}
