package Utilities;

public class Library {
	public static final String RESOURCE_PATH = "./res";
	
	public static final String GAME_TITLE = "Meteor Starter Kit";
	public static final String GAME_VERSION = "0.1a";
}
